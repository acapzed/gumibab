Add-Type -AssemblyName System.Drawing
$b = New-Object System.Drawing.Bitmap(128,128)
$g = [System.Drawing.Graphics]::FromImage($b)
$g.Clear([System.Drawing.Color]::FromArgb(255,0,169,224))
$f = New-Object System.Drawing.Font("Segoe UI", 36, [System.Drawing.FontStyle]::Bold)
$br = New-Object System.Drawing.SolidBrush([System.Drawing.Color]::White)
$fm = New-Object System.Drawing.StringFormat
$fm.Alignment = [System.Drawing.StringAlignment]::Center
$fm.LineAlignment = [System.Drawing.StringAlignment]::Center
$r = New-Object System.Drawing.RectangleF(0,0,128,128)
$g.DrawString("EAT", $f, $br, $r, $fm)
$b.Save("C:\Git\gumibab\planeat-extension\icon.png", [System.Drawing.Imaging.ImageFormat]::Png)
$g.Dispose()
$b.Dispose()
